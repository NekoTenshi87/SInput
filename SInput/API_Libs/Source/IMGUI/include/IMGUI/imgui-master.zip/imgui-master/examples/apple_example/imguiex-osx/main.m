//
//  main.m
//  imguiex-osx
//
//  Created by James Chen on 4/5/16.
//  Copyright © 2016 Joel Davis. All rights reserved.
//

#import <Cocoa/Cocoa.h>

int main(int argc, const char * argv[]) {
    return NSApplicationMain(argc, argv);
}
